#include <GL/glut.h>
#include <stdlib.h>
//Variaveis para funcionamento do jogo
int ini = 1;
int aleatorio;
int vezal;
int npass = 1;
int contav = 0;
//variaveis para desenho do passaro
double pPassaro0_x = 118;
double pPassaro1_x = 115;
double pPassaro2_y = 256 - 129;
double pPassaro3_y = 256 - 122;
double pPassaro4_x = 120;
double pPassaro5_y = 256 - 119;
double pPassaro6_x = 125;
double pPassaro7_x = 134;
BOOLEAN restart = true;
//variaveis para desenho do cano superior
double fCano1x = 256;
double fCano1y = 180;
double fCano2x = 277;
double fCano2y = 256;
double fCano3x = 253;
double fCano4x = 280;
double fCano5y = 201;
//variaveis para desenho do cano inferior
double fCano1x1 = 256;
double fCano3x1 = 253;
double fCano1y1 = 0;
double fCano2x1 = 277;
double fCano4x1 = 280;
double fCano2y1 = 76;
double fCano5y1 = 55;

//velocidade que o passaro cai
double variacao = 0.07;
//velocidade que os canos passam
double velocidadeCano = 0.06;
//variavel para velocidade do salto do passaro
int vsalto = 25;

void init(void);
void display(void);
void mouse(int button, int state, int x, int y);

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
	glutInitWindowSize(256, 256);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("FlappyGL");
	init();
	glutDisplayFunc(display);
	glutMouseFunc(mouse);
	glutMainLoop();
	return 0;
}


void init(void) {
	glClearColor(1.0, 1.0, 1.0, 1.0);
	glOrtho(0, 256, 0, 256, -1, 1);
	
}

void display(void) {
	glClear(GL_COLOR_BUFFER_BIT);
	
	
	//Preenchimento POLIGONO PASSARO
	glColor4f(1.0, 1.0, 0.0, 0.4);
	glBegin(GL_POLYGON);
	glVertex2i(pPassaro0_x + 16, pPassaro2_y + 8);
	glVertex2i(pPassaro0_x + 18, pPassaro2_y + 8);
	glVertex2i(pPassaro0_x + 18, pPassaro2_y + 6);
	glVertex2i(pPassaro0_x + 20, pPassaro2_y + 6);
	glVertex2i(pPassaro0_x + 20, pPassaro2_y + 4);
	glVertex2i(pPassaro0_x + 22, pPassaro2_y + 4);
	glVertex2i(pPassaro0_x + 22, pPassaro2_y + 2);
	glVertex2i(pPassaro0_x + 24, pPassaro2_y + 2);
	glVertex2i(pPassaro0_x + 24, pPassaro2_y - 5);
	glVertex2i(pPassaro0_x + 26, pPassaro2_y - 5);
	glVertex2i(pPassaro0_x + 26, pPassaro2_y - 7);
	glVertex2i(pPassaro0_x + 24, pPassaro2_y - 7);
	glVertex2i(pPassaro0_x + 24, pPassaro2_y - 9);
	glVertex2i(pPassaro0_x + 16, pPassaro2_y - 9);
	glVertex2i(pPassaro0_x + 16, pPassaro2_y - 11);
	glVertex2i(pPassaro0_x + 7, pPassaro2_y - 11);
	glVertex2i(pPassaro0_x + 7, pPassaro2_y - 9);
	glVertex2i(pPassaro0_x + 4, pPassaro2_y - 9);
	glVertex2i(pPassaro0_x + 4, pPassaro2_y - 7);
	glVertex2i(pPassaro0_x + 2, pPassaro2_y - 7);
	glVertex2i(pPassaro0_x + 2, pPassaro2_y - 3);
	glVertex2i(pPassaro0_x, pPassaro2_y - 3);
	glVertex2i(pPassaro0_x, pPassaro2_y);
	glVertex2i(pPassaro1_x, pPassaro2_y);
	glVertex2i(pPassaro1_x, pPassaro3_y);
	glVertex2i(pPassaro4_x, pPassaro3_y);
	glVertex2i(pPassaro4_x, pPassaro5_y);
	glVertex2i(pPassaro6_x, pPassaro5_y);
	glVertex2i(pPassaro6_x, pPassaro5_y + 2);
	glVertex2i(pPassaro7_x, pPassaro5_y + 2);
	glEnd();
	//FIM preenchimento POLIGONO PASSARO


	//CONTORNO PASSARO
	glColor3f(0.0, 0.0, 0.0);
	glBegin(GL_LINE_LOOP);
	glVertex2i(pPassaro0_x + 16, pPassaro2_y +8);
	glVertex2i(pPassaro0_x + 18, pPassaro2_y +8);
	glVertex2i(pPassaro0_x + 18, pPassaro2_y +6);
	glVertex2i(pPassaro0_x + 20, pPassaro2_y +6);
	glVertex2i(pPassaro0_x + 20, pPassaro2_y +4);
	glVertex2i(pPassaro0_x + 22, pPassaro2_y +4);
	glVertex2i(pPassaro0_x + 22, pPassaro2_y +2);
	glVertex2i(pPassaro0_x + 24, pPassaro2_y +2);
	glVertex2i(pPassaro0_x + 24, pPassaro2_y -5);
	glVertex2i(pPassaro0_x + 26, pPassaro2_y -5);
	glVertex2i(pPassaro0_x + 26, pPassaro2_y -7);
	glVertex2i(pPassaro0_x + 24, pPassaro2_y -7);
	glVertex2i(pPassaro0_x + 24, pPassaro2_y -9);
	glVertex2i(pPassaro0_x + 16, pPassaro2_y -9);
	glVertex2i(pPassaro0_x + 16, pPassaro2_y -11);
	glVertex2i(pPassaro0_x + 7, pPassaro2_y -11);
	glVertex2i(pPassaro0_x + 7, pPassaro2_y -9);
	glVertex2i(pPassaro0_x + 4, pPassaro2_y -9);
	glVertex2i(pPassaro0_x + 4, pPassaro2_y -7);
	glVertex2i(pPassaro0_x + 2, pPassaro2_y -7);
	glVertex2i(pPassaro0_x + 2, pPassaro2_y -3);
	glVertex2i(pPassaro0_x, pPassaro2_y -3);
	glVertex2i(pPassaro0_x, pPassaro2_y);
	glVertex2i(pPassaro1_x, pPassaro2_y);
	glVertex2i(pPassaro1_x, pPassaro3_y);
	glVertex2i(pPassaro4_x, pPassaro3_y);  
	glVertex2i(pPassaro4_x, pPassaro5_y);  
	glVertex2i(pPassaro6_x, pPassaro5_y);  
	glVertex2i(pPassaro6_x, pPassaro5_y + 2);  
	glVertex2i(pPassaro7_x, pPassaro5_y + 2);  
	glEnd();
	//FIM CONTORNO PASSARO


	//INICIO ASAS
	glColor3f(1.0, 1.0, 1.0);
	glBegin(GL_POLYGON);
	glVertex2i(pPassaro0_x, pPassaro2_y - 1);
	glVertex2i(pPassaro6_x, pPassaro2_y - 1);
	glVertex2i(pPassaro6_x, pPassaro2_y - 4);
	glVertex2i(pPassaro0_x, pPassaro2_y - 4);
	glEnd();
	//Contorno asas
	glColor3f(0.0, 0.0, 0.0);
	glBegin(GL_LINE_LOOP);
	glVertex2i(pPassaro0_x, pPassaro2_y - 1);
	glVertex2i(pPassaro6_x, pPassaro2_y - 1);
	glVertex2i(pPassaro6_x, pPassaro2_y - 4);
	glVertex2i(pPassaro0_x, pPassaro2_y - 4);
	glEnd();
	//FIM ASAS


	//INICIO CANO SUPERIOR
	glColor3f(0.0, 1.0, 0.0);
	glBegin(GL_POLYGON);
	glVertex2i(fCano1x, fCano1y);
	glVertex2i(fCano1x, fCano2y);
	glVertex2i(fCano2x, fCano2y);
	glVertex2i(fCano2x, fCano1y);
	glEnd();
	//contorno cano superior
	glColor3f(0.0, 0.0, 0.0);
	glBegin(GL_LINE_LOOP);
	glVertex2i(fCano1x, fCano1y);
	glVertex2i(fCano1x, fCano2y);
	glVertex2i(fCano2x, fCano2y);
	glVertex2i(fCano2x, fCano1y);
	glEnd();
	//topo do cano superior
	glColor3f(0.0, 1.0, 0.0);
	glBegin(GL_POLYGON);
	glVertex2i(fCano3x, fCano1y);
	glVertex2i(fCano4x, fCano1y);
	glVertex2i(fCano4x, fCano5y);
	glVertex2i(fCano3x, fCano5y);
	glEnd();
	//contorno do topo do cano superior
	glColor3f(0.0, 0.0, 0.0);
	glBegin(GL_LINE_LOOP);
	glVertex2i(fCano3x, fCano1y);
	glVertex2i(fCano4x, fCano1y);
	glVertex2i(fCano4x, fCano5y);
	glVertex2i(fCano3x, fCano5y);
	glEnd();
	//FIM CANO
	 
	//INICIO CANO INFERIOR
	glColor3f(0.0, 1.0, 0.0);
	glBegin(GL_POLYGON);
	glVertex2i(fCano1x1, fCano1y1);
	glVertex2i(fCano1x1, fCano2y1);
	glVertex2i(fCano2x1, fCano2y1);
	glVertex2i(fCano2x1, fCano1y1);
	glEnd();
	//CONTORNO CANO
	glColor3f(0.0, 0.0, 0.0);
	glBegin(GL_LINE_LOOP);
	glVertex2i(fCano1x1, fCano1y1);
	glVertex2i(fCano1x1, fCano2y1);
	glVertex2i(fCano2x1, fCano2y1);
	glVertex2i(fCano2x1, fCano1y1);
	glEnd();
	//BORDAS CANO
	glColor3f(0.0, 1.0, 0.0);
	glBegin(GL_POLYGON);
	glVertex2i(fCano3x1, fCano2y1);
	glVertex2i(fCano4x1, fCano2y1);
	glVertex2i(fCano4x1, fCano5y1);
	glVertex2i(fCano3x1, fCano5y1);
	glEnd();
	//CONTORNO BORDAS CANO
	glColor3f(0.0, 0.0, 0.0);
	glBegin(GL_LINE_LOOP);
	glVertex2i(fCano3x1, fCano2y1);
	glVertex2i(fCano4x1, fCano2y1);
	glVertex2i(fCano4x1, fCano5y1);
	glVertex2i(fCano3x1, fCano5y1);
	glEnd();
	//FIM CANO

	//condição para que tudo fique em movimento
	if (restart == false) {
		//variavel para determinar a altura maxima e minima da posição atual 
		int val = pPassaro5_y - 2;
		int val1 = pPassaro2_y - 8;

		//colisor dos Canos superior e inferior com o passaro
		if ((pPassaro0_x + 26 >= fCano1x) && (fCano2x >= pPassaro1_x)) {
			if ((val >= fCano1y) || (val1 <= fCano2y1)) {
				npass = 2;
			}
			
		}

		//Reposicionar canos inferiores
		if (fCano2x1 <= 0) {

			//valor aleatorio para mecher nas alturas do cano
			aleatorio = rand() % 50 +1;

			//variavel para determinar se o espaço para o passaro passar vai ser em cima ou em baixo
			vezal = rand() % 2 +1;
			//condicional que movimenta para cima ou para baixo a altura do cano inferior
			if (vezal == 1) {
				fCano2y1 = 76 + aleatorio;
				fCano5y1 = 55 + aleatorio;
			}
			if (vezal == 2) {
				fCano2y1 = 76 - aleatorio;
				fCano5y1 = 55 - aleatorio;
			}
			
			//incrementar velocidade do cano a cada DUAS VEZES que passar !
			if (contav == 2) {

				velocidadeCano = velocidadeCano + 0.01;
				contav = 0;
			}

			else {
				contav++;
			}
			//Reposicionando os canos
			fCano1x1 = 256;
			fCano2x1 = 277;
			fCano3x1 = 253;
			fCano4x1 = 280;
			
			

		}

		//Reposicionar canos superiores
		if (fCano2x <= 0) {
			//condicional que movimenta para cima ou para baixo a altura do cano superior
			if (vezal == 1) {
				fCano1y = 180 + aleatorio;
				fCano5y = 201 + aleatorio;
				}
			if (vezal == 2) {
				fCano1y = 180 - aleatorio;
				fCano5y = 201 - aleatorio;
				}
			
			// Reposicionando os canos
			fCano1x = 256;
			fCano2x = 277;
			fCano3x = 253;
			fCano4x = 280;
		}

		//Colisor altura maxima
		if (val >= 255) {
			npass = 2;
		}
		//Colisor altura minima
		if (val1 <= 2) {
			npass = 2;
		}

		//condicional que mantem o passaro caindo e os canos andando caso ela seja negada
		if (npass == 2) {
				restart = true;
			}
		
			else {
			
				//movimento de queda do passaro
				pPassaro2_y = pPassaro2_y - variacao;
				pPassaro3_y = pPassaro3_y - variacao;
				pPassaro5_y = pPassaro5_y - variacao;
				//movimento do cano superior e inferior
				fCano1x = fCano1x - velocidadeCano;
				fCano2x = fCano2x - velocidadeCano;
				fCano3x = fCano3x - velocidadeCano;
				fCano4x = fCano4x - velocidadeCano;
				fCano1x1 = fCano1x1 - velocidadeCano;
				fCano2x1 = fCano2x1 - velocidadeCano;
				fCano3x1 = fCano3x1 - velocidadeCano;
				fCano4x1 = fCano4x1 - velocidadeCano;
			}
		
		
		glutPostRedisplay();
	}

	glFlush();
	glutSwapBuffers();
}


void mouse(int button, int state, int x, int y) {
	switch (button) {
	case GLUT_LEFT_BUTTON:

		if (state == GLUT_DOWN) {
			//condicional para que ao abrir o passaro nao comece a cair
			if (ini == 1) {
				restart = false;
				ini = 0;
			}
			//iniciando a movimentação toda e movimentando o passaro para cima
			if (restart == false) {
			
				pPassaro2_y = pPassaro2_y + vsalto;
				pPassaro3_y = pPassaro3_y + vsalto;
				pPassaro5_y = pPassaro5_y + vsalto;
			
			}
			glutPostRedisplay();
		}
		break;
	
	}
}

